import streamlit as st
import ollama
import chromadb
import pymupdf
import hashlib
import re

# ==========================================
# 1. PAGE CONFIGURATION
# ==========================================
st.set_page_config(
    page_title="StudyMate AI",
    page_icon="📚",
    layout="wide"
)

st.title("📚 StudyMate AI")
st.caption("Your personal AI study assistant for any subject.")

# ==========================================
# 2. CONNECT TO CHROMADB
# ==========================================
client = chromadb.PersistentClient(path="./studymate_db")

# ==========================================
# 3. UPLOAD STUDY NOTES
# ==========================================
uploaded_file = st.file_uploader(
    "Upload your study notes (PDF)",
    type=["pdf"]
)

if uploaded_file is None:
    st.info("Upload a PDF to start chatting or prepare for exams.")
    st.stop()

pdf_bytes = uploaded_file.getvalue()
file_hash = hashlib.sha256(pdf_bytes).hexdigest()[:20]
collection_name = f"notes_{file_hash}"

collection = client.get_or_create_collection(
    name=collection_name,
    metadata={"description": "StudyMate uploaded PDF notes"}
)

# ==========================================
# 4. EXTRACT TEXT AND STORE EMBEDDINGS
# ==========================================
if collection.count() == 0:
    with st.spinner("Reading your PDF and preparing notes..."):
        try:
            document = pymupdf.open(stream=pdf_bytes, filetype="pdf")
            full_text = "\n".join(page.get_text() for page in document).strip()
            document.close()

            if not full_text:
                st.error(
                    "No selectable text was found in this PDF. "
                    "Scanned PDFs need OCR support, which we will add later."
                )
                st.stop()

            words = full_text.split()
            chunk_size = 250
            overlap = 40
            chunks = []
            start = 0

            while start < len(words):
                end = min(start + chunk_size, len(words))
                chunks.append(" ".join(words[start:end]))
                if end == len(words):
                    break
                start = end - overlap

            batch_size = 32
            for batch_start in range(0, len(chunks), batch_size):
                batch = chunks[batch_start:batch_start + batch_size]
                embedding_result = ollama.embed(
                    model="nomic-embed-text",
                    input=batch
                )
                ids = [
                    f"chunk_{i}"
                    for i in range(batch_start, batch_start + len(batch))
                ]
                collection.add(
                    ids=ids,
                    documents=batch,
                    embeddings=embedding_result["embeddings"],
                    metadatas=[
                        {"chunk_index": batch_start + i}
                        for i in range(len(batch))
                    ]
                )

            st.success(f"Prepared {len(chunks)} chunks.")

        except Exception as error:
            st.error(f"Could not process this PDF: {error}")
            st.stop()

st.caption(f"📄 Document: {uploaded_file.name}")
st.caption(f"📚 Stored chunks: {collection.count()}")

if collection.count() == 0:
    st.warning("No text chunks are available in this document.")
    st.stop()

# ==========================================
# 5. SHARED RETRIEVAL FUNCTION
# ==========================================
def retrieve_context(search_text, number_of_chunks=12):
    """Retrieve passages using the student's actual topic or question."""

    embedding_result = ollama.embed(
        model="nomic-embed-text",
        input=search_text
    )
    query_vector = embedding_result["embeddings"][0]

    results = collection.query(
        query_embeddings=[query_vector],
        n_results=min(number_of_chunks, collection.count()),
        include=["documents", "distances", "metadatas"]
    )

    passages = results["documents"][0] or []
    distances = results["distances"][0] or []
    metadatas = results["metadatas"][0] or []

    return passages, distances, metadatas


def make_context(passages):
    """Label passages so the model can refer to evidence clearly."""
    return "\n\n".join(
        f"Source passage {i + 1}:\n{passage}"
        for i, passage in enumerate(passages)
    )


def generate_chat_answer(question, context):
    """Generate a grounded answer; avoid inventing examples."""
    system_prompt = """
You are StudyMate AI, a careful academic tutor.
Use the supplied source passages as the only source for document-specific facts.
Answer the student's actual question, not a different question.
For requests for examples:
- Give examples only when they are supported by the supplied passages.
- Identify the concept each example illustrates.
- Do not label the same example as two different learning types.
- If the student asks for examples of multiple categories, use separate headings
  for each category and include a category only if the notes support it.
- Do not force a list of categories if the source does not contain examples for them.
If evidence is missing, say which part is not covered by the retrieved passages.
Do not fill gaps with general knowledge while implying it came from the PDF.
Use simple English and keep the answer organized.
"""
    response = ollama.chat(
        model="qwen2.5:3b",
        messages=[
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": (
                    f"Student question:\n{question}\n\n"
                    f"Source passages:\n{context}\n\n"
                    "Answer the question using these passages. "
                    "Do not invent or misclassify examples."
                )
            }
        ],
        options={"temperature": 0}
    )
    return response["message"]["content"].strip()


# ==========================================
# 6. TABS FOR CHAT AND EXAM PREPARATION
# ==========================================
chat_tab, exam_tab = st.tabs([
    "💬 Ask Your Notes",
    "🎓 Exam Preparation Studio"
])

# ==========================================
# 7. CHAT FEATURE
# ==========================================
with chat_tab:
    st.subheader("Ask questions about your notes")

    if st.session_state.get("active_document") != file_hash:
        st.session_state.messages = []
        st.session_state.active_document = file_hash

    if "messages" not in st.session_state:
        st.session_state.messages = []

    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    question = st.chat_input("Ask a question about your notes...")

    if question:
        st.session_state.messages.append(
            {"role": "user", "content": question}
        )
        with st.chat_message("user"):
            st.markdown(question)

        with st.chat_message("assistant"):
            try:
                with st.spinner("Searching your notes..."):
                    passages, distances, _ = retrieve_context(
                        question,
                        number_of_chunks=5
                    )

                    if not passages:
                        answer = (
                            "I couldn't find relevant information "
                            "in this document."
                        )
                    else:
                        context = make_context(passages)
                        answer = generate_chat_answer(question, context)

                st.markdown(answer)

                with st.expander("View retrieved passages"):
                    for i, passage in enumerate(passages):
                        distance = distances[i] if i < len(distances) else None
                        distance_label = (
                            f" — Distance: {distance:.4f}"
                            if distance is not None else ""
                        )
                        st.markdown(f"**Passage {i + 1}{distance_label}**")
                        st.write(passage)

            except Exception as error:
                answer = (
                    "Could not answer this question. Check that Ollama is "
                    f"running and both models are available.\n\nDetails: {error}"
                )
                st.error(answer)

        st.session_state.messages.append(
            {"role": "assistant", "content": answer}
        )


# ==========================================
# 8. EXAM PREPARATION PROMPT BUILDER
# ==========================================
def build_exam_prompt(
    question_type,
    topic,
    marks,
    answer_style,
    difficulty,
    count,
    context
):
    """Create strict instructions tailored to the selected output format."""

    if question_type == "Multiple-choice questions (MCQs)":
        format_instructions = """
FORMAT: MULTIPLE-CHOICE QUESTIONS ONLY.
For every item, use this exact structure:
### Question 1
**[Question text]**
A. [Option]
B. [Option]
C. [Option]
D. [Option]
**Correct answer:** [letter and full option text]
**Explanation:** [why the answer is supported by the notes]

Rules:
- Every question must have exactly four options labelled A, B, C, D.
- There must be exactly one best correct answer per question.
- Make the three incorrect options plausible, but contradicted or unsupported
  by the source material.
- Include the correct answer and explanation after every question.
- Do not produce a summary, revision notes, or essay instead of MCQs.
- Do not label the output as multiple-select questions.
IMPORTANT FORMATTING RULES:
- Put each question on a separate line.
- Put options A, B, C, and D on four separate lines.
- Put the correct answer on its own line.
- Put the explanation on its own line.
- Never combine multiple options on the same line.
- Leave a blank line between questions.
"""
    elif question_type == "Passage-based questions":
        format_instructions = """
FORMAT: PASSAGE-BASED QUESTIONS WITH ANSWERS.
Create a short source-based passage for each set using only information
faithfully paraphrased from the supplied notes. Do not put invented quotations
in quotation marks or pretend a paraphrase is an exact quotation.
After each passage, create questions that require students to use that passage.
Provide a model answer for every question. Label the passage, questions,
answers, and marks clearly. Do not produce MCQs unless they are explicitly
part of the requested passage-based format.
"""
    elif question_type == "Point-wise revision notes":
        format_instructions = """
FORMAT: TOPIC-FOCUSED EXAM REVISION NOTES.

The student has selected a specific topic. Focus primarily
on that topic, not on the whole subject.

Requirements:
1. Start with the exact topic as the main heading.
2. Give a clear, accurate definition using the supplied notes.
3. Organize the material under relevant headings such as:
   - Meaning and definition
   - Key concepts and characteristics
   - Types or categories
   - Working process or steps
   - Examples explicitly supported by the notes
   - Advantages and limitations
   - Applications
   - Differences from related concepts
4. Include only sections relevant to the selected topic
   and supported by the supplied passages.
5. Explain concepts in simple, student-friendly English.
6. Use numbered headings, bullet points, and short paragraphs.
7. Explain important technical terms rather than just
   listing them.
8. Include important exam facts and common distinctions.
9. End with 3 to 5 likely exam questions and concise
   answers, based only on the supplied notes.
10. Do not begin with phrases like "Here is a summary".
11. Do not replace detailed notes with a generic overview.
12. Do not invent facts, examples, quotations, or page
    references. If the notes lack enough information,
    clearly identify the missing information.

Return revision notes only, not a multiple-choice paper.
"""
    elif question_type == "Short-answer questions":
        format_instructions = """
FORMAT: SHORT-ANSWER QUESTIONS AND MODEL ANSWERS.
Number every question. Put the model answer immediately after it.
Keep answers concise and suitable for the selected marks and answer style.
Use a definition plus the key points needed to answer the question.
Do not produce MCQ options or a general summary.
"""
    elif question_type == "Long-answer questions":
        format_instructions = """
FORMAT: LONG-ANSWER EXAM QUESTIONS AND MODEL ANSWERS.
Number every question. Give each a structured model answer with a suitable
introduction/definition, headings, explained key points, and a conclusion
when appropriate. Use examples only when supported by the notes.
Make answers detailed enough for the selected marks and answer style.
Do not produce MCQs or a general revision summary.
"""
    else:
        format_instructions = """
FORMAT: A MIXED QUESTION-AND-ANSWER SET.
Create a varied combination of suitable exam question types, such as short
answers, explanations, comparisons, applications, and MCQs where appropriate.
Clearly label the type of each question and include a model answer for every
item. Do not make every item the same type. Do not return revision notes alone.
"""

    topic_instruction = (
        topic.strip()
        if topic and topic.strip()
        else "Cover the main topics present in the supplied source passages."
    )

    if marks == "Not applicable":
        mark_instruction = "Marks are not applicable to revision notes."
    elif marks == "Mixed marks":
        mark_instruction = (
            "Use a sensible mix of 2-, 5-, and 10-mark questions. "
            "Show the mark allocation beside every question."
        )
    else:
        mark_instruction = (
            f"Each question is worth {marks}. Show the mark allocation. "
            "Match the depth and length of the answer to these marks."
        )

    return f"""
You are StudyMate AI, an academic exam-preparation assistant.

TASK:
Generate exactly {count} items in the selected format: {question_type}.
The selected format is mandatory. Do not substitute another format.

TOPIC:
{topic_instruction}

DIFFICULTY:
{difficulty}. Easy means basic recall and understanding; Exam level means
typical academic exam questions; Challenging means deeper comparison or
reasoning, but only where the source supports it.

ANSWER STYLE:
{answer_style}. Apply this style to every model answer where answers are
requested. If the student selected "Examples where supported by notes",
include examples only when the source actually supports them.

MARKS:
{mark_instruction}

REQUIRED OUTPUT FORMAT:
{format_instructions}

SOURCE AND ACCURACY RULES:
- Use only the supplied passages for claims about the uploaded notes.
- Do not invent facts, examples, quotations, page numbers, or source references.
- Paraphrase faithfully; do not change the meaning of the source.
- If the passages do not support a potential question and answer, choose a
  different supported topic instead.
- Avoid duplicate questions and duplicate answers.
- Clearly separate every item so the student can study from it.
- For question formats, every question must have its model answer.
- Do not claim that questions are guaranteed to appear in a real examination.
- Do not begin with a generic summary. Start directly with the selected format.
- Finish all {count} items; do not stop after an introduction.

SOURCE PASSAGES:
{context}
"""


def output_matches_format(output, question_type, count):
    """Check basic format markers for every supported exam output type."""
    text = output.strip()
    if not text:
        return False, "The model returned an empty response."

    question_headings = len(re.findall(
        r"(?im)^\s*(?:#{1,4}\s*)?(?:question\s*)?\d+\s*[\.\):\-]",
        text
    ))
    answer_labels = len(re.findall(
        r"(?i)(?:\*\*)?(?:model answer|correct answer|answer key|answer)"
        r"(?:\*\*)?\s*:",
        text
    ))

    if question_type == "Multiple-choice questions (MCQs)":
        # Accept A. text, A) text, A: text, including bullet-prefixed options.
        option_count = len(re.findall(
            r"(?im)^\s*(?:[-*•]\s*)?(?:\*\*)?(?:A|B|C|D)(?:\*\*)?\s*[\.\):]\s+",
            text
        ))
        explanation_count = len(re.findall(
            r"(?im)^\s*(?:[-*•]\s*)?(?:\*\*)?explanation(?:\*\*)?\s*:",
            text
        ))
        if option_count < count * 4 or answer_labels < count:
            return False, (
                f"MCQ check failed: found {option_count} option lines "
        f"and {answer_labels} answer labels for {count} questions."
            )
        if explanation_count < count:
            return False, "Each MCQ must also include an explanation."

    elif question_type == "Short-answer questions":
        if question_headings < count or answer_labels < count:
            return False, (
                f"Short-answer check failed: expected {count} numbered "
                "questions and a labelled model answer for each."
            )

    elif question_type == "Long-answer questions":
        if question_headings < count or answer_labels < count:
            return False, (
                f"Long-answer check failed: expected {count} numbered "
                "questions and a labelled model answer for each."
            )
        if len(re.findall(r"(?im)^\s*#{1,4}\s+", text)) < 2:
            return False, "Long answers should use headings to structure explanations."

    elif question_type == "Passage-based questions":
        passage_count = len(re.findall(r"(?i)\bpassage\s*\d*\s*:?", text))
        if passage_count < 1 or question_headings < count or answer_labels < count:
            return False, (
                f"Passage-based check failed: expected a labelled passage, "
                f"{count} numbered questions, and model answers."
            )

    elif question_type == "Point-wise revision notes":
        bullet_count = len(re.findall(r"(?m)^\s*(?:[-*•]|\d+[\.\)])\s+", text))
        heading_count = len(re.findall(r"(?m)^\s*#{1,4}\s+", text))
        if bullet_count < 3 or heading_count < 1:
            return False, (
                "Revision-notes check failed: expected topic headings and "
                "at least three bullet points. Do not return a prose summary."
            )

    elif question_type == "Mixed questions":
        if question_headings < count or answer_labels < count:
            return False, (
                f"Mixed-question check failed: expected {count} numbered "
                "questions and a labelled model answer for each."
            )
        mcq_option_count = len(re.findall(
            r"(?im)^\s*(?:[-*]\s*)?(?:\*\*)?(?:A|B|C|D)(?:\*\*)?[\.\)]\s+",
            text
        ))
        # Mixed output may include MCQs, but must not be only a summary.
        if not re.search(r"(?i)\b(question|model answer|correct answer)\b", text):
            return False, "The output does not look like a question-and-answer set."

    return True, ""


def generate_exam_material(
    question_type,
    topic,
    marks,
    answer_style,
    difficulty,
    count,
    context
):
    """Generate once, validate the selected format, then retry if needed."""
    prompt = build_exam_prompt(
        question_type, topic, marks, answer_style,
        difficulty, count, context
    )

    response = ollama.chat(
        model="qwen2.5:3b",
        messages=[
            {
                "role": "system",
                "content": (
                    "Follow the selected study-material format exactly. "
                    "Do not substitute a generic summary for a question set. "
                    "For every requested question, include its answer. "
                    "For revision notes, produce headings and bullet points. "
                    "Use only the supplied notes for source-specific facts."
                )
            },
            {"role": "user", "content": prompt}
        ],
        options={"temperature": 0}
    )
    output = response["message"]["content"].strip()
    valid, reason = output_matches_format(output, question_type, count)

    if not valid:
        # Give each format its own corrective requirements, not just MCQs.
        if question_type == "Multiple-choice questions (MCQs)":
            correction = f"""
Regenerate from scratch as exactly {count} MCQs. Each item must have a
numbered heading, A., B., C., D. options, **Correct answer:** and
**Explanation:**. No summary or revision notes.
"""
        elif question_type == "Passage-based questions":
            correction = f"""
Regenerate from scratch. Include at least one clearly labelled source-based
passage, then exactly {count} numbered questions, each followed by
**Model answer:**. Base the passage and answers only on the supplied notes.
Do not return a general summary.
"""
        elif question_type == "Point-wise revision notes":
            correction = f"""
Regenerate from scratch as revision notes, NOT questions. Include clear
Markdown topic headings and concise bullet points. Cover the selected topic
if provided. Do not return an opening prose summary instead of notes.
"""
        elif question_type == "Short-answer questions":
            correction = f"""
Regenerate from scratch as exactly {count} numbered short-answer exam
questions. Immediately after every question, include **Model answer:** with
a concise answer appropriate to {marks} and {answer_style}. No summary.
"""
        elif question_type == "Long-answer questions":
            correction = f"""
Regenerate from scratch as exactly {count} numbered long-answer exam
questions. Each must have **Model answer:** followed by a detailed answer
with meaningful Markdown headings and explained key points. Match {marks},
{difficulty}, and {answer_style}. No summary.
"""
        else:
            correction = f"""
Regenerate from scratch as exactly {count} numbered mixed exam questions.
Use varied question types rather than repeating one type. Each question must
have a labelled **Model answer:** (or **Correct answer:** for MCQs).
Do not return revision notes or a generic summary.
"""

        retry_prompt = (
            prompt
            + "\n\nFORMAT VALIDATION FAILED:\n"
            + reason
            + "\n\nMANDATORY CORRECTION:\n"
            + correction
            + "\n\nReturn only the requested material and include every item."
        )
        retry = ollama.chat(
            model="qwen2.5:3b",
            messages=[
                {
                    "role": "system",
                    "content": (
                        "Obey the selected format and correction requirements. "
                        "Do not replace the requested output with a summary."
                    )
                },
                {"role": "user", "content": retry_prompt}
            ],
            options={"temperature": 0}
        )
        output = retry["message"]["content"].strip()
        valid, reason = output_matches_format(output, question_type, count)

    return output, valid, reason


# ==========================================
# 9. EXAM PREPARATION STUDIO
# ==========================================
with exam_tab:
    st.subheader("🎓 Exam-Ready Questions & Answers")
    st.write(
        "Choose the study material you need. StudyMate AI will tailor its "
        "output to the selected format, topic, marks, and difficulty."
    )

    with st.form("exam_generator_form"):
        topic = st.text_input(
            "Topic (optional)",
            placeholder="e.g., supervised learning; leave blank for broad coverage"
        )

        question_type = st.selectbox(
            "What would you like to generate?",
            [
                "Mixed questions",
                "Multiple-choice questions (MCQs)",
                "Passage-based questions",
                "Point-wise revision notes",
                "Short-answer questions",
                "Long-answer questions"
            ]
        )

        mark_options = ["2 marks", "5 marks", "10 marks", "Mixed marks"]
        if question_type == "Point-wise revision notes":
            marks = "Not applicable"
            st.info("Point-wise revision notes do not require marks.")
        else:
            marks = st.selectbox("Marks per question", mark_options, index=1)

        answer_style = st.selectbox(
            "Answer style",
            [
                "Detailed model answer",
                "Point-wise answer",
                "Brief answer",
                "Examples where supported by notes"
            ]
        )

        difficulty = st.selectbox(
            "Difficulty",
            ["Easy", "Exam level", "Challenging"],
            index=1
        )

        count = st.select_slider(
            "Number of questions or items",
            options=[5, 10, 15, 20, 25, 30],
            value=10
        )

        generate_button = st.form_submit_button(
            "✨ Generate Study Material",
            type="primary",
            use_container_width=True
        )
if generate_button:
    if topic.strip():
        search_text = topic.strip()
    else:
        search_text = (
            "Important definitions, concepts, processes, comparisons, "
            "advantages, limitations, applications, and key topics "
            "from the study notes."
        )

    try:
        with st.spinner("Retrieving notes and generating your material..."):
            passages, distances, metadatas = retrieve_context(
                search_text,
                number_of_chunks=12
            )

            if not passages:
                st.warning("No relevant notes were retrieved.")
            else:
                context = make_context(passages)

                exam_material, format_valid, format_warning = (
                    generate_exam_material(
                        question_type=question_type,
                        topic=topic,
                        marks=marks,
                        answer_style=answer_style,
                        difficulty=difficulty,
                        count=count,
                        context=context
                    )
                )

                st.session_state["exam_material"] = exam_material
                st.session_state["exam_document"] = file_hash
                st.session_state["exam_sources"] = passages
                st.session_state["exam_distances"] = distances
                st.session_state["exam_format"] = question_type
                st.session_state["exam_format_valid"] = format_valid
                st.session_state["exam_format_warning"] = format_warning

    except Exception as error:
        st.error(
            "Could not generate study material. Check that Ollama is "
            "running and the qwen2.5:3b and nomic-embed-text models are "
            f"available.\n\nDetails: {error}"
        )
    # Display saved results across Streamlit reruns
    if st.session_state.get("exam_document") == file_hash:
        exam_material = st.session_state.get("exam_material")

        if exam_material:
            st.divider()
            st.subheader("📝 Your Study Material")

            if not st.session_state.get("exam_format_valid", True):
                st.error(
                    "The generated response did not pass the format check "
                    "for your selected option. Please review it carefully; "
                    "it may be incomplete or in the wrong format. Try again "
                    "with a smaller item count or a more specific topic. "
                    "Details: "
                    + st.session_state.get(
                        "exam_format_warning",
                        "The output structure could not be verified."
                    )
                )
            st.markdown(exam_material)

            st.download_button(
                "⬇️ Download Study Material",
                data=exam_material,
                file_name="studymate_exam_material.md",
                mime="text/markdown",
                key="download_exam_material"
            )

            with st.expander("View source passages used"):
                source_passages = st.session_state.get("exam_sources", [])
                source_distances = st.session_state.get("exam_distances", [])

                for i, passage in enumerate(source_passages):
                    distance_text = ""
                    if i < len(source_distances):
                        distance_text = f" — Distance: {source_distances[i]:.4f}"
                    st.markdown(f"**Source passage {i + 1}{distance_text}**")
                    st.write(passage)

st.divider()
st.caption(
    "StudyMate AI | Local AI with Ollama and ChromaDB. "
    "Always review generated answers against your original notes."
)
